/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapppart_1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
     Login login = new Login();
     
     @Test
     public void testValidcheckUsername(){
         //this checks the username must have the underscore"_"
         //also checks the length of the username must not be more than 5 (e.g "
         
         assertTrue(login.checkUserName("kyl_1"));
     }
     
     @Test
     public void testInvalidUsername_NoUnderscore(){
         //checks the username with no underscore
         assertFalse(login.checkUserName("abcd1"));
     }
     
     @Test 
     public void testInvalidUsername_TooLong(){
         //reasons why it is FASLE, the username is more than 5 characters
         //it was suppose to be 5 (e.g "kyl_1")
         assertFalse(login.checkUserName("kylee_"));             
    }
     
     @Test
     public void testValidPassword(){
         //checks if password meets the complexity requirements
         assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
         
     }
     @Test 
     public void testInvalidPassword(){
         //Checks password with no capital letter,number and special character
         //Checks password with less than 8 characters
         assertFalse(login.checkPasswordComplexity("password"));
     }
     
     @Test
     public void testValidPhoneNumber(){
         //Checks the correctly formatted phone number 
         assertTrue(login.checkCellPhoneNumber("+27838968976"));
     }
     
     @Test
     public void testInvalidPhoneNumber(){
         //Checks phone number that is formatted incorrectly,does not contain an international code
         assertFalse(login.checkCellPhoneNumber("08966553"));
         
     }
     
     
}

      
